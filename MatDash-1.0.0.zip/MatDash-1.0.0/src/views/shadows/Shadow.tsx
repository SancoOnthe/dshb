import { AllShadows } from "src/components/shadows/AllShadows"


const Shadow = () => {
  return (
    <AllShadows/>
  )
}

export default Shadow