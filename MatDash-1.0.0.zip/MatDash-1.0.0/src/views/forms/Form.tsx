
import BasicForm from 'src/components/forms/BasicForm'

const Form = () => {
  return (
    <BasicForm/>
  )
}

export default Form