import BasicTypography from "src/components/typography/BasicTypography"


const Typography = () => {
  return (
    <BasicTypography/>
  )
}

export default Typography